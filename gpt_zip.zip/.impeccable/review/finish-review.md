disposition: fix

Inputs: code-led build; no approved comp or quality-bar card supplied. Superseded sketches are not visual authority. Reviewed the pinned brief and original implementation request directly; no interview was needed for this independent review.

## persistence

Pass. PRODUCT.md, the confirmed research brief, and the surface direction contract exist. Preservation of the two protected source documents is a parent-provided constraint; this review did not independently establish a before/after baseline. DESIGN.md is pending the post-review documenter and is not a failure at this stage. No comp reproduction state or raster plate obligations apply to this code-led analytical surface. Parent reports the sole detector finding was a documented false positive; no second detector was run.

## fidelity

| Element / promise | Assessment | Evidence |
|---|---|---|
| TYPE | match | Source Sans 3, restrained heading hierarchy and tabular data suit the pinned research-tool direction. |
| MATERIAL | match | Real interactive cartography and numerical visualizations; clean geometry, no fabricated physical treatment. |
| GROUND | match | Cool pale green analytical ground, white work areas and forest structural shell; no beige drift. |
| THESIS / FIRST VIEWPORT | match | Desktop capture gives map and calendar equal width and nearly equal height; timeline follows in a compact lower band. No KPI-card scaffold. |
| OWN-WORLD | match | Forest navigation and selections, orange activity, explicit blue VIIRS identity, fine separators and restrained controls. |
| STORY | match with material exception | Import, shared scope, map inspection and source traceability are implemented. Timeline unavailable-period semantics require the fix below. |
| FORM | match | Pinned observation chronology and Research Atlas refinement are explicit user corrections; `seed: none (pinned)` is appropriate. |
| Responsive composition | adaptation | Mobile stacks the peer instruments and locally scrolls the calendar while preserving year/month context, as the confirmed brief requires. |
| Authentic source records | match within reviewed evidence | Datasets capture shows MODIS 6,827, Terra/Aqua, version 61.03; VIIRS 47,364, S-NPP, version 2; both observed extents are 2024-01-01–2024-12-31. Source hashes, validation and unknown-coverage language remain visible. |
| Unavailable versus zero | contradicted | Calendar explicitly marks outside sensor record extent unavailable; timeline fills every missing sensor/bin with zero and renders that zero wherever the sensor is loaded. Non-overlapping periods therefore imply zero-count continuity through unavailable data. |

## ceiling

The pinned Operate world is reached visually. The first viewport reads as observation instruments rather than a decorative dashboard. No absent ornament or motion is required by this restrained direction. Cluster circles could carry counts for faster broad-scale reading, but this is optional and does not block this build.

Audit scores use 0 = absent/broken and 4 = fully evidenced for the reviewed scope:

| Dimension | Score | Evidence and limit |
|---|---:|---|
| Accessibility | 3/4 | Labeled controls, visible focus rules, skip link, native details, calendar table and map/timeline table alternatives; no independent assistive-technology, full keyboard or contrast audit performed. |
| Performance | 3/4 | Worker import, memoized filters, GeoJSON clustering, lazy map/chart loading and explicit 25 MB / 100,000-record budgets. Parent reports passing build with a large MapLibre chunk warning; no low-end device profiling. |
| Theming | 3/4 | Coherent tokens, focus/selection/caret treatment and semantic sensor colors. Single light analytical theme is the pinned scope; map colors remain literals rather than all tokens. |
| Responsive | 3/4 | Valid full-page desktop 1440-wide and mobile 390-wide captures, readable stacked work areas and localized calendar scrolling. Parent reports no document horizontal overflow; tablets, zoom and physical devices were not independently tested. |
| Integrity | 2/4 | Authentic sources, retained platforms, raw counts, duplicate prevention and provenance are explicit. The unavailable-period timeline issue remains material for historical expansion. |

Evidence: `.impeccable/review/desktop.png`, `mobile.png`, and `datasets.png` were opened and inspected; all show document tops, expected content and settled map tiles, with no blank or black regions. Source inspection covered App, study state, filters, map, calendar, timeline, comparison, aggregation, parsing, repository, import worker and relevant CSS. Parent reports nine unit/archive checks and the comprehensive linked-workspace Playwright check passing; this reviewer inspected test code but did not rerun tests. Current captures cover matching 2024 extents, so they do not validate non-overlapping historical data.

## material_fixes

1. **Truth / required unavailable-data state:** In `src/data/analytics.ts` (`buildBins`) and `src/components/Timeline.tsx`, distinguish bins outside each loaded sensor's observed record extent from zero matching records inside that extent. Plot unavailable bins as gaps/nulls and label them explicitly in tooltip and accessible table; retain the caveat that record extent never establishes observation coverage. Verify a non-overlapping MODIS/VIIRS import and a date range wholly outside the loaded extent. Calendar, timeline and comparison must communicate the same distinction.

## keep

Preserve the balanced map/calendar, cool green structure, orange activity, distinct raw sensor streams, source/platform provenance, protected source documents and scoped scientific language. Scope/limits: independent file-and-capture review only; no browser interaction, scientific validation, physical-device testing or accessibility certification; no code edited. Re-review the targeted fix with valid captures and regression evidence before shipping.
