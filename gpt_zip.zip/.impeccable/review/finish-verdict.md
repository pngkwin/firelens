## verdict

1. **Resolved — unavailable-period timeline semantics.** Reopened all five supplied final captures. `availability.png` visibly shows isolated authentic MODIS January and VIIRS December values, no zero bridge across missing periods, and explicit “Unknown / outside extent” table cells. Calendar unavailable months and comparison “No shared interval” agree with this state. Source inspection confirms sensor-specific nulls, disconnected gaps, isolated-point dots and explicit tooltip text; unknown-coverage caveats remain. Parent reports 10/10 unit checks, 3/3 Playwright checks (including the non-overlapping authentic subsets and all twelve outside-extent 2023 months), and a passing production build. Tests were not independently rerun by this reviewer.

No regressions attributable to this fix are visible in regenerated desktop, mobile, datasets, hotspot or availability captures. All five captures are valid. Updated integrity score: **3/4**; other audit scores remain **3/4**, giving **15/20** across the five reviewed dimensions. Evidence remains a source/capture review with parent-reported execution, not accessibility certification or physical-device validation.

## remaining

Clear for the scored fix. This ship verdict covers the scored fix, not a new full-surface review. Original review remains the historical baseline; no UI or source documents were edited by this reviewer.

disposition: ship
