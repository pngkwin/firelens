# FireLens

A scientific workspace for exploring authentic NASA FIRMS active-fire observations across geography, time, and sensor. Raw MODIS and VIIRS observations remain separate; no scientific harmonization or anomaly model is applied.

## Run locally

Use Node.js 22.12 or newer (verified here with Node 26).

```sh
npm install
npm run dev
```

Open the local URL printed by Vite. `predev` validates historical CSVs under `data/raw/`, prepares byte-identical deployment copies in `public/data/`, and writes their checksums and inventory. The downloaded NASA training sample is deliberately excluded from the default dataset.

```sh
npm test
npm run test:e2e
npm run build
npm run preview
```

Browser tests use installed Microsoft Edge in headless mode. To use another Playwright browser, change `channel` in `playwright.config.ts` and install the corresponding browser. Archive integration and browser tests require the two original CSVs at the paths recorded in `docs/data-inventory.json`.

## Current real observations

| Source file | Instrument | Platforms | Retained records | UTC record extent |
|---|---|---|---:|---|
| fire_archive_M-C61_850214.csv | MODIS Collection 6.1 | Terra 3,596; Aqua 3,231 | 6,827 | 2024-01-01–2024-12-31 |
| fire_archive_SV-C2_850215.csv | VIIRS Collection 2, 375 m | S-NPP | 47,364 | 2024-01-01–2024-12-31 |

Both validated with zero rejected rows and zero duplicate observations. These are user-supplied approved FIRMS archive downloads. Originals are unchanged. Full schemas, coordinates, hashes, and monthly/platform counts are in `docs/data-inventory.json`.

The current regional subset is not a product restriction. Other regions, dates, and VIIRS platform identities can be imported through the same pipeline. The application starts with empty import guidance when no historical files are available.

## Data semantics

- FIRMS archive and near-real-time CSV variants are supported. The archive uses `instrument=SNPP` and `satellite=SNPP` for VIIRS S-NPP and labels its thermal columns `brightness` and `bright_t31`; the normalization layer preserves these original labels and the source identity alongside canonical VIIRS/S-NPP identity.
- Latitude and longitude are WGS84 geographic coordinates. `acq_date` and zero-padded `acq_time` are interpreted as UTC. Invalid coordinates, times, dates, incompatible satellite/instrument pairs, and structurally malformed rows are rejected and reported.
- Confidence stays source-specific. No common numerical confidence threshold is applied. FRP, thermal fields, day/night, source version, and type code are retained when supplied. All supplied source type codes are included; no vegetation-only filter is applied.
- Calendar cells count records for one instrument. Timeline series and comparison totals remain separate. The common comparison interval is the intersection of loaded sensor record extents and study dates, not proof of matched satellite coverage.
- A zero is a count of matching records in the loaded dataset, never evidence that no fire occurred. Coverage is unknown; periods outside loaded record extents are marked separately.
- Exact-file SHA-256 checks prevent repeated imports. Observation keys combine instrument, platform, UTC timestamp, and coordinates. First imported observations win even across versions; overlapping records are reported rather than added twice. If you remove the first dataset, skipped overlaps are not automatically restored; reimport the later original if needed.
- User imports are schema-validated but are not authenticated as NASA-origin files. Bundled files are checked against inspected SHA-256 hashes at runtime.

Official sources: [FIRMS archive](https://firms.modaps.eosdis.nasa.gov/download/), [archive README and disclaimer](https://firms.modaps.eosdis.nasa.gov/download/Readme.txt), [active-fire products](https://firms.modaps.eosdis.nasa.gov/content/active_fire/), [NASA data-ingest tutorial](https://firms.modaps.eosdis.nasa.gov/content/academy/data_ingest/firms_data_ingest.html). Basemap: [OpenFreeMap](https://openfreemap.org/quick_start/), with OpenMapTiles/OpenStreetMap attribution retained by MapLibre. Maps need network access and WebGL; the observation table provides a non-map inspection path.

## Architecture and limits

`src/data/` owns parsing, normalization, a replaceable data repository, filtering, and time aggregation. CSV validation runs in a Web Worker. `src/state/StudyContext.tsx` owns one shared study state. Reusable views in `src/components/` consume its scoped and focused observations. MapLibre renders clustered GeoJSON, without individual React markers. Map and chart code are loaded separately from the shell; fonts are self-hosted.

Limits: 25 MB per CSV, 100,000 retained records per workspace. The entire supported regional dataset remains in memory; large multi-decade work needs preprocessing or a backend query repository. Imports and removals last for the browser session; reloading restores bundled archives. Region drawing currently uses a two-corner bounding box, with manual coordinate entry and antimeridian support as an accessible alternative. No polygon workflow, persistent project storage, or analysis export is claimed.

## Deployment and source preservation

Vercel: Vite framework, build command `npm run build`, output `dist`. `prebuild` regenerates deployment CSV copies and the manifest from `data/raw/`. Raw CSVs/archives and generated public CSVs are gitignored to avoid committing large originals and duplicate deployment copies. Provision the originals in the build environment to bundle them; without them a clean deployment intentionally starts empty and supports browser CSV import. Do not assume an uncommitted local archive will appear in a Git-based deployment. No backend or API key is required for local CSV exploration.

The checked-in manifest/inventory records provenance, not data availability. The build regenerates the public manifest from files actually present. `PRODUCT.md` and the confirmed research brief remain unchanged.

Next milestone: reproducible, versioned study persistence and a query/preprocessing layer for larger historical archives, before proposing and independently validating sensor harmonization methods.
