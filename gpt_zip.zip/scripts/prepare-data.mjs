import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import Papa from "papaparse";
import {
  normalizeRow,
  normalizeHeader,
  validateHeaders,
} from "../src/data/normalize.ts";

const root = "data/raw";
const csvs = fs
  .readdirSync(root, { recursive: true })
  .filter(
    (p) =>
      p.toLowerCase().endsWith(".csv") && !p.toLowerCase().includes("sample"),
  );
fs.mkdirSync("public/data", { recursive: true });
const manifest = [];
for (const name of csvs) {
  const filePath = path.join(root, name);
  const bytes = fs.readFileSync(filePath);
  const parsed = Papa.parse(bytes.toString("utf8"), {
    header: true,
    skipEmptyLines: "greedy",
    transformHeader: normalizeHeader,
  });
  validateHeaders(parsed.meta.fields ?? []);
  const valid = [];
  const errors = [];
  const seen = new Set();
  let duplicates = 0;
  parsed.data.forEach((row, index) => {
    try {
      const r = normalizeRow(row, "inspection");
      if (seen.has(r.id)) duplicates++;
      else {
        valid.push(r);
        seen.add(r.id);
      }
    } catch (e) {
      errors.push({ row: index + 1, error: e.message });
    }
  });
  if (parsed.errors.length || errors.length)
    throw new Error(
      `Validation failed for ${name}: ${JSON.stringify([...parsed.errors, ...errors].slice(0, 10))}`,
    );
  const dates = valid.map((r) => r.date).sort();
  const filename = path.basename(name);
  const summary = {
    name: filename,
    path: filePath.replaceAll("\\", "/"),
    url: `/data/${filename}`,
    source: "https://firms.modaps.eosdis.nasa.gov/download/",
    origin:
      "User-supplied approved NASA FIRMS archive download; preserved original CSV",
    hash: crypto.createHash("sha256").update(bytes).digest("hex"),
    bytes: bytes.length,
    inputRows: parsed.data.length,
    records: valid.length,
    duplicates,
    rejected: errors.length,
    sensors: [...new Set(valid.map((r) => r.sensor))],
    satellites: [...new Set(valid.map((r) => r.satellite))],
    versions: [...new Set(valid.map((r) => r.version))],
    rawInstruments: [...new Set(parsed.data.map((r) => r.instrument))],
    start: dates[0],
    end: dates.at(-1),
    bounds: {
      west: Math.min(...valid.map((r) => r.longitude)),
      south: Math.min(...valid.map((r) => r.latitude)),
      east: Math.max(...valid.map((r) => r.longitude)),
      north: Math.max(...valid.map((r) => r.latitude)),
    },
    fields: parsed.meta.fields,
    inspectedAt: new Date().toISOString(),
  };
  fs.copyFileSync(filePath, path.join("public/data", filename));
  summary.platformCounts = Object.fromEntries(
    summary.satellites.map((s) => [
      s,
      valid.filter((r) => r.satellite === s).length,
    ]),
  );
  summary.monthlyCounts = Object.fromEntries(
    [...new Set(valid.map((r) => r.date.slice(0, 7)))]
      .sort()
      .map((period) => [
        period,
        valid.filter((r) => r.date.startsWith(period)).length,
      ]),
  );
  manifest.push(summary);
}
fs.writeFileSync(
  "public/data/manifest.json",
  JSON.stringify(manifest, null, 2),
);
fs.writeFileSync("docs/data-inventory.json", JSON.stringify(manifest, null, 2));
console.log(
  manifest
    .map(
      (d) =>
        `${d.name}: ${d.records.toLocaleString()} ${d.sensors.join("/")} records; ${d.satellites.join("/")} · ${d.start} — ${d.end}; ${d.rejected} rejected; ${d.duplicates} duplicates`,
    )
    .join("\n") ||
    "No historical CSVs found. The app will open with an import state.",
);
