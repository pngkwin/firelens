import { useMemo, useState } from "react";
import { CalendarDays, X } from "lucide-react";
import { useStudy } from "../state/StudyContext";
import { aggregate, sensorExtent } from "../data/analytics";
import type { Sensor } from "../data/types";
const months = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];
export function Calendar() {
  const { datasets, scoped, filters, extent, updateFilters } = useStudy();
  const [chosenSensor, setChosenSensor] = useState<Sensor>("VIIRS");
  const sensor = filters.sensor === "all" ? chosenSensor : filters.sensor;
  const sourceExtent = useMemo(
    () => sensorExtent(datasets, sensor),
    [datasets, sensor],
  );
  const bins = useMemo(
    () => new Map(aggregate(scoped).map((b) => [b.period, b])),
    [scoped],
  );
  const max = Math.max(1, ...[...bins.values()].map((b) => b[sensor]));
  const start = filters.start || extent.start;
  const end = filters.end || extent.end;
  const years =
    start && end && start <= end
      ? Array.from(
          { length: Math.min(201, +end.slice(0, 4) - +start.slice(0, 4) + 1) },
          (_, i) => +start.slice(0, 4) + i,
        )
      : [];
  const [hover, setHover] = useState("");
  function cell(period: string) {
    const before = `${period}-31` < start;
    const after = `${period}-01` > end;
    const unknown =
      !sourceExtent ||
      `${period}-31` < sourceExtent.start ||
      `${period}-01` > sourceExtent.end;
    return {
      count: bins.get(period)?.[sensor] ?? 0,
      unavailable: before || after || unknown,
    };
  }
  return (
    <section className="calendar-panel" aria-labelledby="calendar-title">
      <div className="section-heading">
        <div>
          <h2 id="calendar-title">Burning activity calendar</h2>
          <p>Monthly detection counts · raw observations</p>
        </div>
        <CalendarDays size={18} className="muted-icon" />
      </div>
      <div className="calendar-toolbar">
        <div className="segmented" role="group" aria-label="Calendar sensor">
          {(["MODIS", "VIIRS"] as Sensor[]).map((s) => (
            <button
              key={s}
              className={sensor === s ? "active" : ""}
              aria-pressed={sensor === s}
              disabled={filters.sensor !== "all" && filters.sensor !== s}
              onClick={() => {
                setChosenSensor(s);
                updateFilters({ month: null });
              }}
            >
              {s}
              <span className={`sensor-dot ${s.toLowerCase()}`} />
            </button>
          ))}
        </div>
        <span className="calendar-unit">Records / month</span>
      </div>
      <div className="calendar-scroll">
        <table className="calendar-table">
          <caption className="sr-only">
            Monthly {sensor} detection counts in the loaded dataset. Zero does
            not establish absence of fire or observation coverage.
          </caption>
          <thead>
            <tr>
              <th scope="col">Year</th>
              {months.map((m) => (
                <th scope="col" key={m}>
                  {m}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {years.map((year) => (
              <tr key={year}>
                <th scope="row">{year}</th>
                {months.map((month, index) => {
                  const period = `${year}-${String(index + 1).padStart(2, "0")}`;
                  const { count, unavailable } = cell(period);
                  return (
                    <td key={period}>
                      <button
                        disabled={unavailable}
                        aria-label={`${month} ${year}: ${unavailable ? "no loaded record extent" : `${count.toLocaleString()} ${sensor} detections; coverage unknown`}`}
                        aria-pressed={filters.month === period}
                        title={
                          unavailable
                            ? "Outside loaded record extent; coverage unknown"
                            : `${count.toLocaleString()} ${sensor} detections. Select to focus.`
                        }
                        className={`heat-cell ${unavailable ? "unknown" : count === 0 ? "zero" : `heat-${Math.max(1, Math.ceil((count / max) * 5))}`} ${filters.month === period ? "selected" : ""}`}
                        onMouseEnter={() =>
                          setHover(
                            `${month} ${year} · ${count.toLocaleString()} ${sensor} detections`,
                          )
                        }
                        onMouseLeave={() => setHover("")}
                        onFocus={() =>
                          setHover(
                            `${month} ${year} · ${count.toLocaleString()} ${sensor} detections`,
                          )
                        }
                        onBlur={() => setHover("")}
                        onClick={() =>
                          updateFilters({
                            month: filters.month === period ? null : period,
                          })
                        }
                      >
                        {unavailable ? "—" : count.toLocaleString()}
                      </button>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
        {!years.length && (
          <div className="calendar-empty">
            <CalendarDays size={28} />
            <h3>Your historical record starts here</h3>
            <p>
              Import official FIRMS observations to reveal monthly patterns
              across years.
            </p>
          </div>
        )}
        {years.length > 0 && !sourceExtent && (
          <p className="inline-note">
            No {sensor} dataset loaded. Import this instrument to compare its
            monthly history.
          </p>
        )}
      </div>
      <div className="calendar-readout" aria-live="polite">
        {hover ||
          (filters.month
            ? `Selected ${filters.month} · map and timeline focused`
            : "Select a month to focus the linked map and timeline.")}
        {filters.month && (
          <button
            className="text-button"
            onClick={() => updateFilters({ month: null })}
          >
            Clear <X size={12} />
          </button>
        )}
      </div>
      <div className="heat-legend">
        <span>Fewer</span>
        {[1, 2, 3, 4, 5].map((n) => (
          <i key={n} className={`heat-${n}`} />
        ))}
        <span>{max.toLocaleString()}</span>
        <span className="legend-separator">— Unknown / outside extent</span>
      </div>
      <div className="calendar-note">
        <strong>Observation history, not a harmonized index.</strong>
        <p>
          Values count loaded {sensor} records. A zero means no matching
          records; coverage remains unknown.{" "}
          {sourceExtent
            ? `Record extent: ${sourceExtent.start} – ${sourceExtent.end}.`
            : "No source extent available."}
        </p>
      </div>
    </section>
  );
}
