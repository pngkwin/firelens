import { useMemo } from "react";
import { useStudy } from "../state/StudyContext";
import { sensorExtent } from "../data/analytics";
export function SensorComparison() {
  const { datasets, focused, filters } = useStudy();
  const modis = useMemo(() => sensorExtent(datasets, "MODIS"), [datasets]);
  const viirs = useMemo(() => sensorExtent(datasets, "VIIRS"), [datasets]);
  const start =
    modis && viirs
      ? [
          modis.start,
          viirs.start,
          filters.start || "1900-01-01",
          filters.month ? `${filters.month}-01` : "1900-01-01",
        ]
          .sort()
          .at(-1)!
      : "";
  const end =
    modis && viirs
      ? [
          modis.end,
          viirs.end,
          filters.end || "2100-12-31",
          filters.month
            ? `${filters.month}-${new Date(Date.UTC(+filters.month.slice(0, 4), +filters.month.slice(5, 7), 0)).getUTCDate()}`
            : "2100-12-31",
        ].sort()[0]
      : "";
  const common = !!start && start <= end;
  const comparable = common
    ? focused.filter((r) => r.date >= start && r.date <= end)
    : [];
  return (
    <section className="comparison-panel" aria-labelledby="comparison-title">
      <h2 id="comparison-title">Sensor comparison</h2>
      <p>Same region and date interval. Separate observations.</p>
      <div className="sensor-comparison">
        {(["MODIS", "VIIRS"] as const).map((s) => (
          <div key={s}>
            <h3>
              <i className={`sensor-dot ${s.toLowerCase()}`} />
              {s}
            </h3>
            <strong className="comparison-count">
              {!datasets.some((d) => d.sensors.includes(s))
                ? "—"
                : filters.sensor !== "all" && filters.sensor !== s
                  ? "—"
                  : common
                    ? comparable
                        .filter((r) => r.sensor === s)
                        .length.toLocaleString()
                    : "—"}
            </strong>
            <span>
              {!datasets.some((d) => d.sensors.includes(s))
                ? "Not loaded"
                : filters.sensor !== "all" && filters.sensor !== s
                  ? "Filtered out"
                  : common
                    ? "Detection records"
                    : "No shared interval"}
            </span>
            <p>
              {s === "MODIS"
                ? "Terra / Aqua · nominal 1 km"
                : "VIIRS platforms · nominal 375 m"}
            </p>
          </div>
        ))}
      </div>
      <p className="comparison-period">
        {common
          ? `Shared record-date interval: ${start} – ${end}`
          : "Load both instruments with overlapping record dates to compare."}
      </p>
      <p className="analysis-caution">
        No correction factors applied. Counts are not unique fires or burned
        area. Shared record dates do not establish equal observation coverage.
      </p>
    </section>
  );
}
